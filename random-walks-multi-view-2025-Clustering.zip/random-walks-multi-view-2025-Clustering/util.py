import torch
import torch.nn as nn
from torch.distributions.multivariate_normal import MultivariateNormal
L2norm = nn.functional.normalize
# def relaition_matrix (x):
#     sigma=1
#     x_distance = -(torch.norm(x[:, None]-x, dim=2, p=2)*torch.norm(x[:, None]-x, dim=2, p=2))
#     b = 2 *sigma**2
#     W = torch.exp(x_distance/b)
#     #W=W*(W>=0.5).float()
#     return W
def relaition_matrix_ (x):
  N=x.size(0)
  tmp = torch.norm(x, 2, 1)+1e-6;
  x_norm = x / tmp.view(N, -1);
  x_relation=torch.mm( x_norm,x_norm.t())  
  #x_relation=x_relation*(x_relation>=0).float()
  x_relation=torch.clamp(x_relation,min=0.0)
  return x_relation
# def relaition_matrix (x):
#     sigma=2
#     x_distance = -(torch.norm(x[:, None]-x, dim=2, p=2)*torch.norm(x[:, None]-x, dim=2, p=2))
#     b = 2 *sigma**2
#     W = torch.exp(x_distance/b)
#     return W
def data_normalized(data):
    return (data-data.min(dim=0,keepdim=True)[0])/(data.max(dim=0,keepdim=True)[0]-data.min(dim=0,keepdim=True)[0])

# def relaition_matrix(z, temperature=0.5):
#         z = L2norm(z)
#         G = (2 - 2 * (z @ z.t())).clamp(min=0.)
#         G = torch.exp(-G / temperature)
        # return G
def relaition_matrix(z, temperature=2, step: int = 5, similarity="kernel"):#2
        if similarity=="kernel":
              z = L2norm(z)
              G = (2 - 2 * (z @ z.t())).clamp(min=0.)
              G = torch.exp(-G / temperature)
              G = G / G.sum(dim=1, keepdim=True)
        else:
              G=relaition_matrix_(z)
        G = torch.matrix_power(G, step)
        alpha = 0.5
        G = torch.eye(G.shape[0]).cuda() * alpha + G * (1 - alpha)
        return G

def relaition_matrix1(z, temperature=2, step: int = 1,similarity="kernel"):
        if similarity=="kernel":
              z = L2norm(z)
              G = (2 - 2 * (z @ z.t())).clamp(min=0.)
              G = torch.exp(-G / temperature)
              G = G / G.sum(dim=1, keepdim=True)
        else:
              G=relaition_matrix_(z)
        G = torch.matrix_power(G, step)
        alpha = 0.5
        G = torch.eye(G.shape[0]).cuda() * alpha + G * (1 - alpha)
        return G
def relaition_matrix2(G, step: int = 5):
        G = torch.matrix_power(G, step)
        alpha = 0.5
        G = torch.eye(G.shape[0]).cuda() * alpha + G * (1 - alpha)
        return G