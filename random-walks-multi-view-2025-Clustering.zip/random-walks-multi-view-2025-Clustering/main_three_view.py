# -*- coding: utf-8 -*-
"""
Created on Tue Aug 24 16:16:34 2021

@author: danli
"""
import torch
from torch.autograd import Variable
import sys
import time
import itertools
import numpy as np
from multi_view_data import *
from configure_clustering_multiview import get_default_config
from sklearn.cluster import KMeans
from metrics import get_avg_acc,get_avg_nmi,get_avg_RI,get_avg_f1
from torch.utils.data import DataLoader
import scipy.io as sio
import os
os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
os.environ["CUDA_VISIBLE_DEVICES"] = '0'
use_cuda = torch.cuda.is_available()
device = torch.device('cuda:0' if use_cuda else 'cpu')

import warnings
warnings.filterwarnings("ignore")
from multi_view_loss import MultiView_all_loss
from model import IMDD_ThreeView

dataset = {
    0: "ORL_mtv",
    1: "LandUse_21",
    2: "Scene-15",
    3: "COIL20-3v",
    4: "CCV",
    5: "CCV1",

}
dataset = dataset[5]
config = get_default_config(dataset) 
config['dataset'] = dataset
print(config['dataset'])
###################################
train_dataset=ThreeView_Datasets(config,train=True)
test_dataset=ThreeView_Datasets(config,train=False)
batch_size=config['training']['batch_size']
trainloader = DataLoader(train_dataset, batch_size,
                                         shuffle=True, num_workers=0)
testloader=DataLoader(test_dataset, batch_size,
                                         shuffle=False, num_workers=0)
print('Finish loading the data....')
#########################################################################

def train():
    net = IMDD_ThreeView(config)
    lossfunc1 = MultiView_all_loss(batch_size)
    optimizer = torch.optim.Adam(itertools.chain(net.autoencoder1.parameters(),net.autoencoder2.parameters(),net.autoencoder3.parameters()
                                                ),lr=config['training']['lr']) 
    
    print('-' * 10,'Training Start','-' * 10)
    epochs=config['training']['epoch']
    start_time=time.time()
    loss_=[]
    for epoch in range(epochs):
        num_batches = len(trainloader)
        loss_all,loss_AE,loss_contrast= 0,0,0
        for batch_idx,train_data in enumerate(trainloader):
            inputs_x1, inputs_x2,inputs_x3,label_train= train_data 
            inputs_x1,inputs_x2, inputs_x3,label_train= inputs_x1.to(device),inputs_x2.to(device),inputs_x3.to(device), label_train.to(device)
            
            net=net.to(device)
            list_x,list_hat,MMfeature,views_relation,list_relation, list_fusion_relation=net(inputs_x1,inputs_x2,inputs_x3, device)
            loss,loss_pre_AE, loss_pre_contrast= lossfunc1(list_x,list_hat,MMfeature,views_relation,list_relation, list_fusion_relation,3,epoch)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            
            loss_all += loss.item()
            loss_AE  += loss_pre_AE.item()
            loss_contrast += loss_pre_contrast.item()
        if epoch<30:  
            output = "Epoch : {:.0f}/{:.0f} ===> Loss_all = {:.4f}===> Loss_AE = {:.4f} " \
                        "===> loss_contrast = {:.4f}" \
                    .format((epoch + 1), epochs, (loss_all+loss_contrast)/num_batches, loss_AE/num_batches, loss_contrast/num_batches)
        else:
             output = "Epoch : {:.0f}/{:.0f} ===> Loss_all = {:.4f}===> Loss_AE = {:.4f} " \
                        "===> loss_contrast= {:.4f}" \
                    .format((epoch + 1), epochs, loss_all/num_batches, loss_AE/num_batches, loss_contrast/num_batches)
        print(output)
    end_time=time.time()
    traning_time=end_time-start_time  
    print(traning_time)       
        
    print('-' * 10,'Test Start','-' * 10)
    x1_feature = []
    x2_feature = []
    x3_feature = []
    label_all=[]
    net.eval()
    with torch.no_grad():
        for data in testloader:
            x_view=[]
            x1,x2,x3,labels= data
            list_x,list_hat,MMfeature,views_relation,list_relation, list_fusion_relation= net(x1.to(device),x2.to(device),x3.to(device),device)
           
            views_relation = views_relation / views_relation.sum(1, keepdims=True)
            final_view_features=torch.mm(views_relation,MMfeature)
            
            for view in range(3):
                x_view.append(final_view_features[view*x1.size(0):(view+1)*x1.size(0),:])
            
            x1_feature.append(x_view[0])
            x2_feature.append(x_view[1])  
            x3_feature.append(x_view[2])  
            label_all.append(labels)
                
    x_view_final =np.concatenate((torch.cat(x1_feature).cpu().numpy(),torch.cat(x2_feature).cpu().numpy(),torch.cat(x3_feature).cpu().numpy()),axis=1)
    #x_view_final =(torch.cat(x1_feature).cpu().numpy()+torch.cat(x2_feature).cpu().numpy()+torch.cat(x3_feature).cpu().numpy())/3 
    
    label_all = torch.cat(label_all).cpu().numpy()
    label_all=label_all.reshape(len(label_all),)
    estimator=KMeans(config['label_num'])
    label_pred= estimator.fit_predict(x_view_final) 
    return label_pred,label_all,x_view_final,loss_,x1_feature,x2_feature,x3_feature
times=1
pred_all=[]
for t in range(times):
    print('-' * 10,t+1,'-' * 10)
    label_pred,label_all,x_view_final,loss_,x1_feature,x2_feature,x3_feature =train()
    pred_all.append(label_pred)
acc_avg, acc_std = get_avg_acc(label_all, pred_all, times)
nmi_avg, nmi_std = get_avg_nmi(label_all, pred_all, times)
ri_avg, ri_std = get_avg_RI(label_all, pred_all, times)
f1_avg, f1_std = get_avg_f1(label_all, pred_all, times)

print('acc: {acc:.4f}\t'
                'acc_std: {acc_std:.4f}\t'
                'NMI: {NMI:.4f}\t'
                'NMI_std: {nmi_std:.4f}\t'
                'F:{F:.4f}\t'
                'F_std: {f1_std:.4f}\t'
                'RI:{RI:.4f}\t'
                'RI_std: {ri_std:.4f}'.format(acc=acc_avg,acc_std=acc_std,NMI=nmi_avg,nmi_std=nmi_std,F=f1_avg,f1_std=f1_std,RI=ri_avg,ri_std=ri_std))
############################################
# x1_all =torch.cat(x1_feature).cpu().numpy()
# x2_all =torch.cat(x2_feature).cpu().numpy()
# x3_all =torch.cat(x3_feature).cpu().numpy()


# sio.savemat('C:/Users/B/Desktop/paper_code/multi_view_2025/可视化/scene-15/x1_all.mat',{'x1_all':x1_all})   
# sio.savemat('C:/Users/B/Desktop/paper_code/multi_view_2025/可视化/scene-15/x2_all.mat',{'x2_all':x2_all})  
# sio.savemat('C:/Users/B/Desktop/paper_code/multi_view_2025/可视化/scene-15/x3_all.mat',{'x3_all':x3_all})  


# sio.savemat('C:/Users/B/Desktop/paper_code/multi_view_2025/可视化/scene-15/x_view_final.mat',{'x_view_final':x_view_final})
# sio.savemat('C:/Users/B/Desktop/paper_code/multi_view_2025/可视化/scene-15/label_all_hw.mat',{'label_all':label_all}) 
# loss_all =np.array(loss_)
# sio.savemat('C:/Users/B/Desktop/incomplete_multi_view_learning_2024/可视化/loss_all_scene_0.5.mat',{'loss_all':loss_all}) 
# sio.savemat('C:/Users/B/Desktop/incomplete_multi_view_learning_2024/可视化/x_view_final_scene_0.5.mat',{'x_view_final':x_view_final})