
import sys
import scipy.io as sio
import numpy as np
import torch
import os
import torch.utils.data as data
from sklearn import preprocessing
import h5py





class ThreeView_Datasets(data.Dataset):
    def __init__(self,config, train=True):
        self._config=config
        self.train = train
        data_name = self._config['dataset']
        main_dir = r'D:\paper_code\random-walks-multi-view-2025-Clustering'
        
        if data_name =='CCV1':
            data_view1=np.load(os.path.join(main_dir,'dataset', "SIFT" + '.npy'))
            data_view2=np.load(os.path.join(main_dir,'dataset', "STIP" + '.npy'))
            data_view3=np.load(os.path.join(main_dir,'dataset', "MFCC" + '.npy'))
            label=np.load(os.path.join(main_dir,'dataset', "label" + '.npy'))
        else:
            data_multiview = sio.loadmat(os.path.join(main_dir,'dataset', data_name + '.mat'))
            if len(data_multiview['X'])==1:
                data_view1=data_multiview['X'][0,0]
                data_view2=data_multiview['X'][0,1]
                data_view3=data_multiview['X'][0,2]
            else:
                data_view1=data_multiview['X'][0,0]
                data_view2=data_multiview['X'][1,0]
                data_view3=data_multiview['X'][2,0]
            label=data_multiview['Y'] 
        min_max_scaler_1 = preprocessing.MinMaxScaler(feature_range=(0,1)).fit(data_view1)
        data_view1=min_max_scaler_1.transform(data_view1)
        min_max_scaler_2 = preprocessing.MinMaxScaler(feature_range=(0,1)).fit(data_view2)
        data_view2=min_max_scaler_2.transform(data_view2)
        min_max_scaler_3 = preprocessing.MinMaxScaler(feature_range=(0,1)).fit(data_view3)
        data_view3=min_max_scaler_3.transform(data_view3)
        
       
       
        
        if self.train:
            self.train_data_view1 = data_view1
            self.train_data_view2 = data_view2
            self.train_data_view3 = data_view3
            self.train_labels = label  
           
        else:
            self.test_data_view1= data_view1
            self.test_data_view2= data_view2
            self.test_data_view3= data_view3
            self.test_labels = label
           
           
            
    def __getitem__(self, index):
        if self.train:
            view1= self.train_data_view1[index]
            view2=self.train_data_view2[index]
            view3=self.train_data_view3[index]
            target = self.train_labels[index] 
           
        else:
            view1= self.test_data_view1[index]
            view2=self.test_data_view2[index]
            view3=self.test_data_view3[index]
            target = self.test_labels[index]
           
           
       
        view1 = torch.from_numpy(view1).float()
        view2 = torch.from_numpy(view2).float()
        view3 = torch.from_numpy(view3).float()
       
        
        
        target = target.astype(np.int64)
        return view1, view2, view3, target
    
    def __len__(self):
        if self.train:
            return len(self.train_labels)
        else:
            return len(self.test_labels)


class FiveView_Datasets(data.Dataset):
    def __init__(self,config, train=True):
        self._config=config
        self.train = train
        data_name = self._config['dataset']
        main_dir = r'D:\paper_code\random-walks-multi-view-2025-Clustering'
        if data_name=="YoutubeFace_sel":
            data_multiview = h5py.File(os.path.join(main_dir,'dataset', data_name + '.mat'))
            element=np.array(data_multiview['X'])
            data_view1=data_multiview[element[0,0]][:]
            data_view1=data_view1.T
            data_view2=data_multiview[element[1,0]][:] 
            data_view2=data_view2.T
            data_view3=data_multiview[element[2,0]][:] 
            data_view3=data_view3.T
            data_view4=data_multiview[element[3,0]][:] 
            data_view4=data_view4.T
            data_view5=data_multiview[element[4,0]][:]
            data_view5=data_view5.T
            label=(np.array(data_multiview['Y'])).T

        else:
            data_multiview = sio.loadmat(os.path.join(main_dir,'dataset', data_name + '.mat'))
            if len(data_multiview['X'])==1:
                data_view1=data_multiview['X'][0,0]
                data_view2=data_multiview['X'][0,1]
                data_view3=data_multiview['X'][0,2]
                data_view4=data_multiview['X'][0,3]
                data_view5=data_multiview['X'][0,4]
            else:
                data_view1=data_multiview['X'][0,0]
                data_view2=data_multiview['X'][1,0]
                data_view3=data_multiview['X'][2,0]
                data_view4=data_multiview['X'][3,0]
                data_view5=data_multiview['X'][4,0]
            label=data_multiview['Y']
        min_max_scaler_1 = preprocessing.MinMaxScaler(feature_range=(0,1)).fit(data_view1)
        data_view1=min_max_scaler_1.transform(data_view1)
        min_max_scaler_2 = preprocessing.MinMaxScaler(feature_range=(0,1)).fit(data_view2)
        data_view2=min_max_scaler_2.transform(data_view2)
        min_max_scaler_3 = preprocessing.MinMaxScaler(feature_range=(0,1)).fit(data_view3)
        data_view3=min_max_scaler_3.transform(data_view3)
        min_max_scaler_4 = preprocessing.MinMaxScaler(feature_range=(0,1)).fit(data_view4)
        data_view4=min_max_scaler_4.transform(data_view4)
        min_max_scaler_5 = preprocessing.MinMaxScaler(feature_range=(0,1)).fit(data_view5)
        data_view5=min_max_scaler_5.transform(data_view5)
        

        
        if self.train:
            self.train_data_view1 = data_view1
            self.train_data_view2 = data_view2
            self.train_data_view3 = data_view3
            self.train_data_view4 = data_view4
            self.train_data_view5 = data_view5
            self.train_labels = label  
           
        else:
            self.test_data_view1= data_view1
            self.test_data_view2= data_view2
            self.test_data_view3= data_view3
            self.test_data_view4= data_view4
            self.test_data_view5= data_view5
            self.test_labels = label
           
           
            
    def __getitem__(self, index):
        if self.train:
            view1= self.train_data_view1[index]
            view2=self.train_data_view2[index]
            view3=self.train_data_view3[index]
            view4=self.train_data_view4[index]
            view5=self.train_data_view5[index]
            target = self.train_labels[index]  
          
        else:
            view1= self.test_data_view1[index]
            view2=self.test_data_view2[index]
            view3=self.test_data_view3[index]
            view4=self.test_data_view4[index]
            view5=self.test_data_view5[index]
            target = self.test_labels[index]
           
           
       
        view1 = torch.from_numpy(view1).float()
        view2 = torch.from_numpy(view2).float()
        view3 = torch.from_numpy(view3).float()
        view4 = torch.from_numpy(view4).float()
        view5 = torch.from_numpy(view5).float()
       
        
        target = target.astype(np.int64)
        return view1, view2, view3, view4, view5,target
    
    def __len__(self):
        if self.train:
            return len(self.train_labels)
        else:
            return len(self.test_labels)


class   SixView_Datasets(data.Dataset):
    def __init__(self,config, train=True):
        self._config=config
        self.train = train
        data_name = self._config['dataset']
        main_dir = r'D:\paper_code\random-walks-multi-view-2025-Clustering'
        if data_name=="AwA":
            data_multiview = h5py.File(os.path.join(main_dir,'dataset', data_name + '.mat'))
            element=np.array(data_multiview['X'])
            data_view1=data_multiview[element[0,0]][:]
            data_view1=data_view1.T
            data_view2=data_multiview[element[1,0]][:] 
            data_view2=data_view2.T
            data_view3=data_multiview[element[2,0]][:] 
            data_view3=data_view3.T
            data_view4=data_multiview[element[3,0]][:] 
            data_view4=data_view4.T
            data_view5=data_multiview[element[4,0]][:]
            data_view5=data_view5.T
            data_view6=data_multiview[element[5,0]][:] 
            data_view6=data_view6.T
            label=(np.array(data_multiview['Y'])).T
        else:
           data_multiview = sio.loadmat(os.path.join(main_dir,'dataset', data_name + '.mat'))
           if len(data_multiview['X'])==1:
                data_view1=data_multiview['X'][0,0]
                data_view2=data_multiview['X'][0,1]
                data_view3=data_multiview['X'][0,2]
                data_view4=data_multiview['X'][0,3]
                data_view5=data_multiview['X'][0,4]
                data_view6=data_multiview['X'][0,5]
           else:
                data_view1=data_multiview['X'][0,0]
                data_view2=data_multiview['X'][1,0]
                data_view3=data_multiview['X'][2,0]
                data_view4=data_multiview['X'][3,0]
                data_view5=data_multiview['X'][4,0]
                data_view6=data_multiview['X'][5,0]
           label=data_multiview['Y']
        min_max_scaler_1 = preprocessing.MinMaxScaler().fit(data_view1)
        data_view1=min_max_scaler_1.transform(data_view1)
        min_max_scaler_2 = preprocessing.MinMaxScaler().fit(data_view2)
        data_view2=min_max_scaler_2.transform(data_view2)
        min_max_scaler_3 = preprocessing.MinMaxScaler().fit(data_view3)
        data_view3=min_max_scaler_3.transform(data_view3)
        min_max_scaler_4 = preprocessing.MinMaxScaler().fit(data_view4)
        data_view4=min_max_scaler_4.transform(data_view4)
        min_max_scaler_5 = preprocessing.MinMaxScaler().fit(data_view5)
        data_view5=min_max_scaler_5.transform(data_view5)
        min_max_scaler_6 = preprocessing.MinMaxScaler().fit(data_view6)
        data_view6=min_max_scaler_6.transform(data_view6)
        
        if self.train:
            self.train_data_view1 = data_view1
            self.train_data_view2 = data_view2
            self.train_data_view3 = data_view3
            self.train_data_view4 = data_view4
            self.train_data_view5 = data_view5
            self.train_data_view6 = data_view6
            self.train_labels = label
           
        else:
            self.test_data_view1= data_view1
            self.test_data_view2= data_view2
            self.test_data_view3= data_view3
            self.test_data_view4= data_view4
            self.test_data_view5= data_view5
            self.test_data_view6= data_view6
            self.test_labels = label
        
            
    def __getitem__(self, index):
        if self.train:
            view1= self.train_data_view1[index]
            view2=self.train_data_view2[index]
            view3=self.train_data_view3[index]
            view4=self.train_data_view4[index]
            view5=self.train_data_view5[index]
            view6=self.train_data_view6[index]
            target = self.train_labels[index] 
          
        else:
            view1= self.test_data_view1[index]
            view2=self.test_data_view2[index]
            view3=self.test_data_view3[index]
            view4=self.test_data_view4[index]
            view5=self.test_data_view5[index]
            view6=self.test_data_view6[index]
            target = self.test_labels[index]
           
       
        view1 = torch.from_numpy(view1).float()
        view2 = torch.from_numpy(view2).float()
        view3 = torch.from_numpy(view3).float()
        view4 = torch.from_numpy(view4).float()
        view5 = torch.from_numpy(view5).float()
        view6 = torch.from_numpy(view6).float()
       
        
        target = target.astype(np.int64)

        return view1, view2, view3, view4, view5, view6, target
    
    def __len__(self):
        if self.train:
            return len(self.train_labels)
        else:
            return len(self.test_labels)

class   FourView_Datasets(data.Dataset):
    def __init__(self,config, train=True):
        self._config=config
        self.train = train
        data_name = self._config['dataset']
        main_dir = r'D:\paper_code\random-walks-multi-view-2025-Clustering\dataset'
        if data_name == "YTF10_4":
             data_multiview = h5py.File(os.path.join(main_dir,'dataset', data_name + '.mat'))
             data_view1=np.array(data_multiview[data_multiview['X'][0,0]]).T
             data_view2=np.array(data_multiview[data_multiview['X'][0,1]]).T
             data_view3=np.array(data_multiview[data_multiview['X'][0,2]]).T
             data_view4=np.array(data_multiview[data_multiview['X'][0,3]]).T 
             label=np.array(data_multiview['Y']).T

            
        else:
             data_multiview = sio.loadmat(os.path.join(main_dir,'dataset', data_name + '.mat'))
             if len(data_multiview['X'])==1:
                data_view1=data_multiview['X'][0,0]
                data_view2=data_multiview['X'][0,1]
                data_view3=data_multiview['X'][0,2]
                data_view4=data_multiview['X'][0,3]
                
             else:
                data_view1=data_multiview['X'][0,0]
                data_view2=data_multiview['X'][1,0]
                data_view3=data_multiview['X'][2,0]
                data_view4=data_multiview['X'][3,0]
             label=data_multiview['Y']
        
        min_max_scaler_1 = preprocessing.MinMaxScaler().fit(data_view1)
        data_view1=min_max_scaler_1.transform(data_view1)
        min_max_scaler_2 = preprocessing.MinMaxScaler().fit(data_view2)
        data_view2=min_max_scaler_2.transform(data_view2)
        min_max_scaler_3 = preprocessing.MinMaxScaler().fit(data_view3)
        data_view3=min_max_scaler_3.transform(data_view3)
        min_max_scaler_4 = preprocessing.MinMaxScaler().fit(data_view4)
        data_view4=min_max_scaler_4.transform(data_view4)
    
        
       
        if self.train:
            self.train_data_view1 = data_view1
            self.train_data_view2 = data_view2
            self.train_data_view3 = data_view3
            self.train_data_view4 = data_view4
          
            self.train_labels = label
           
        else:
            self.test_data_view1= data_view1
            self.test_data_view2= data_view2
            self.test_data_view3= data_view3
            self.test_data_view4= data_view4
            
            self.test_labels = label
          
           
            
    def __getitem__(self, index):
        if self.train:
            view1= self.train_data_view1[index]
            view2=self.train_data_view2[index]
            view3=self.train_data_view3[index]
            view4=self.train_data_view4[index]
            
            target = self.train_labels[index] 
           
        else:
            view1= self.test_data_view1[index]
            view2=self.test_data_view2[index]
            view3=self.test_data_view3[index]
            view4=self.test_data_view4[index]
           
            target = self.test_labels[index]
          
       
        view1 = torch.from_numpy(view1).float()
        view2 = torch.from_numpy(view2).float()
        view3 = torch.from_numpy(view3).float()
        view4 = torch.from_numpy(view4).float()
        
       
        
        target = target.astype(np.int64)

        return view1, view2, view3, view4, target
    
    def __len__(self):
        if self.train:
            return len(self.train_labels)
        else:
            return len(self.test_labels)
