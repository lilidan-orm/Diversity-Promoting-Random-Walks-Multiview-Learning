def get_default_config(data_name):
    if data_name in ['handwritten']:#sigmoid
        return dict(
            view=6,
            label_num=10,
            training=dict(
                lr=3.0e-4,
                start_completion=20,
                batch_size=64,
                epoch=100,
            ),
            Autoencoder=dict(
                arch1=[240, 256,  100],
                arch2=[76,  256, 100],
                arch3=[216,  256,  100],
                arch4=[47,  256, 100],
                arch5=[64, 256,  100],
                arch6=[6,  256, 100],
                activations='tanh',
                batchnorm=True,
            )
           
        )

    elif data_name in ['ORL_mtv']:
        """The default configs."""
        return dict(
            view=3,
            label_num=40,
            training=dict(
                lr=1.0e-4,
                start_completion=50,
                batch_size=32,
                epoch=100,
            ),
            Autoencoder=dict(
                arch1=[4096, 1024,  100],
                arch2=[3304, 1024, 100],
                arch3=[6750, 1024, 100],
                activations='relu',
                batchnorm=True,
            )
            

        )
    elif data_name in ['LandUse_21']:#2
        """The default configs."""
        return dict(
            view=3,
            label_num=21,
            Autoencoder=dict(
                arch1=[20, 1024,100],
                arch2=[59, 1024,  100],
                arch3=[40, 1024, 100],
                activations='relu',
                batchnorm=True,
            ),

            training=dict(
                lr=1.0e-4,
                start_completion=50,
                batch_size=128,
                epoch=100,
            ),
        )
    elif data_name in ['Scene-15']:#2
        """The default configs."""
        return dict(
            view=3,
            label_num=15,
            Autoencoder=dict(
                arch1=[20, 1024, 100],
                arch2=[59, 1024,  100],
                arch3=[40, 1024, 100],
                activations='relu',
                batchnorm=True,
            ),
            

            training=dict(
                lr=1.0e-4,
                start_completion=100,
                batch_size=128,
                epoch=100,
            ),
        )
    elif data_name in ['CCV']:
        """The default configs."""
        return dict(
            view=3,
            label_num=20,
            Autoencoder=dict(
                arch1=[20, 256, 100],
                arch2=[20, 256,  100],
                arch3=[20, 256, 100],
                activations='relu',
                batchnorm=True,
            ),
            

            training=dict(
                lr=1.0e-4,
                start_completion=100,
                batch_size=128,
                epoch=100,
            ),
        )
    elif data_name in ['CCV1']:#sigmoid
        """The default configs."""
        return dict(
            view=3,
            label_num=20,
            Autoencoder=dict(
                arch1=[5000, 1024, 100],
                arch2=[5000, 1024,  100],
                arch3=[4000, 1024, 100],
                activations='relu',
                batchnorm=True,
            ),
            
            training=dict(
                lr=1.0e-4,
                start_completion=100,
                batch_size=128,
                epoch=100,
            ),
        )
    
    
    
    
    elif data_name in ['COIL20-3v']:#0.5
        """The default configs."""
        return dict(
            view=3,
            label_num=20,
            Autoencoder=dict(
                arch1=[1024, 1024,  100],
                arch2=[3304, 1024,  100],
                arch3=[6750, 1024, 100],
    
                activations='relu',
                batchnorm=True,
            ),
            training=dict(
                lr=1.0e-4,
                start_completion=50,
                batch_size=64,
                epoch=80,
            ),
        )
    
    elif data_name in ['ALOI-100']:#2
        """The default configs."""
        return dict(
            view=4,
            label_num=100,
            Autoencoder=dict(
                arch1=[77, 1024, 50 ],
                arch2=[13, 1024,  50],
                arch3=[64, 1024,  50],
                arch4=[125, 1024,  50],
               
                activations='tanh',
                batchnorm=True,
            ),
            training=dict(
                lr=1.0e-4,
                start_completion=40,
                batch_size=128,
                epoch=100,
            ),
        )
    
    elif data_name in ['AwA']:#cos
        """The default configs."""
        return dict(
            view=6,
            label_num=50,
            Autoencoder=dict(
                arch1=[2688, 512, 100],
                arch2=[2000, 512,  100],
                arch3=[252, 512, 100],
                arch4=[2000, 512,100],
                arch5=[2000, 512,100],
                arch6=[2000, 512,100],
               
                activations='tanh',
                batchnorm=True,
            ),
            training=dict(
                lr=1.0e-4,
                start_completion=40,
                batch_size=64,
                epoch=100,
            ),
        )
    elif data_name in ['YoutubeFace_sel']:#cos
        """The default configs."""
        return dict(
            view=5,
            label_num=31,
            Autoencoder=dict(
                arch1=[64, 256, 100],
                arch2=[512, 256,  100],
                arch3=[64, 256, 100],
                arch4=[647, 256,100],
                arch5=[838, 256, 100],
                
                activations='tanh',
                batchnorm=True,
            ),
            training=dict(
                lr=1.0e-4,
                start_completion=40,
                batch_size=256,
                epoch=100,
            ),
        )
    
    
    else:
        raise Exception('Undefined data name')
