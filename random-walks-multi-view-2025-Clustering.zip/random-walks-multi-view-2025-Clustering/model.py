from __future__ import print_function, absolute_import, division
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.utils import shuffle
from util import *
from torch.nn.parameter import Parameter

class Autoencoder(nn.Module):
    """AutoEncoder module that projects features to latent space."""

    def __init__(self,
                 encoder_dim,
                 activation='relu',
                 batchnorm=True):
        """Constructor.

        Args:
          encoder_dim: Should be a list of ints, hidden sizes of
            encoder network, the last element is the size of the latent representation.
          activation: Including "sigmoid", "tanh", "relu", "leakyrelu". We recommend to
            simply choose relu.
          batchnorm: if provided should be a bool type. It provided whether to use the
            batchnorm in autoencoders.
        """
        super(Autoencoder, self).__init__()
        self._dim = len(encoder_dim) - 1
        self._activation = activation
        self._batchnorm = batchnorm

        encoder_layers = []
        for i in range(self._dim):
            encoder_layers.append(
                nn.Linear(encoder_dim[i], encoder_dim[i + 1]))
            if i < self._dim - 1:
                if self._batchnorm:
                    encoder_layers.append(nn.BatchNorm1d(encoder_dim[i + 1]))
                if self._activation == 'sigmoid':
                    encoder_layers.append(nn.Sigmoid())
                elif self._activation == 'leakyrelu':
                    encoder_layers.append(nn.LeakyReLU(0.2, inplace=True))
                elif self._activation == 'tanh':
                    encoder_layers.append(nn.Tanh())
                elif self._activation == 'relu':
                    encoder_layers.append(nn.ReLU())
                else:
                    raise ValueError('Unknown activation type %s' % self._activation)
        encoder_layers.append(nn.Sigmoid())
        self._encoder = nn.Sequential(*encoder_layers)

        decoder_dim = [i for i in reversed(encoder_dim)]
        decoder_layers = []
        for i in range(self._dim):
            decoder_layers.append(
                nn.Linear(decoder_dim[i], decoder_dim[i + 1]))
            if self._batchnorm:
                decoder_layers.append(nn.BatchNorm1d(decoder_dim[i + 1]))
            if self._activation == 'sigmoid':
                decoder_layers.append(nn.Sigmoid())
            elif self._activation == 'leakyrelu':
                decoder_layers.append(nn.LeakyReLU(0.2, inplace=True))
            elif self._activation == 'tanh':
                decoder_layers.append(nn.Tanh())
            elif self._activation == 'relu':
                decoder_layers.append(nn.ReLU())
            else:
                raise ValueError('Unknown activation type %s' % self._activation)
        self._decoder = nn.Sequential(*decoder_layers)

    def encoder(self, x):
        """Encode sample features.

            Args:
              x: [num, feat_dim] float tensor.

            Returns:
              latent: [n_nodes, latent_dim] float tensor, representation Z.
        """
        latent = self._encoder(x)
        return latent

    def decoder(self, latent):
        """Decode sample features.

            Args:
              latent: [num, latent_dim] float tensor, representation Z.

            Returns:
              x_hat: [n_nodes, feat_dim] float tensor, reconstruction x.
        """
        x_hat = self._decoder(latent)
        return x_hat

    def forward(self, x):
        """Pass through autoencoder.

            Args:
              x: [num, feat_dim] float tensor.

            Returns:
              latent: [num, latent_dim] float tensor, representation Z.
              x_hat:  [num, feat_dim] float tensor, reconstruction x.
        """
        latent = self.encoder(x)
        x_hat = self.decoder(latent)
        return x_hat, latent




########################################################




class IMDD_ThreeView(nn.Module):
    # Dual contrastive prediction
    def __init__(self, config):
        """Constructor.

        Args:
            config: parameters defined in configure.py.
        """
        super(IMDD_ThreeView, self).__init__()
        self._config = config

        if self._config['Autoencoder']['arch1'][-1] != self._config['Autoencoder']['arch2'][-1]:
            raise ValueError('Inconsistent latent dim!')

        self._latent_dim = config['Autoencoder']['arch1'][-1]
        
        # View-specific autoencoders
        self.autoencoder1 = Autoencoder(config['Autoencoder']['arch1'], config['Autoencoder']['activations'],
                                        config['Autoencoder']['batchnorm'])
        self.autoencoder2 = Autoencoder(config['Autoencoder']['arch2'], config['Autoencoder']['activations'],
                                        config['Autoencoder']['batchnorm'])

        self.autoencoder3 = Autoencoder(config['Autoencoder']['arch3'], config['Autoencoder']['activations'],
                                        config['Autoencoder']['batchnorm'])
        
        
    def forward(self,x1_train, x2_train,x3_train, device):
        view_num=3
        x1_hat,x1_latent=self.autoencoder1(x1_train)
        x2_hat,x2_latent=self.autoencoder2(x2_train)
        x3_hat,x3_latent=self.autoencoder3(x3_train)
        x1_relation=relaition_matrix1(x1_latent)
        x2_relation=relaition_matrix1(x2_latent)
        x3_relation=relaition_matrix1(x3_latent)
        x_fusion=torch.cat((x1_latent,x2_latent,x3_latent),1)
        x_fusion_relation=relaition_matrix1(x_fusion)
        ##########################################
        x1_relation_walk=relaition_matrix(x1_latent)
        x2_relation_walk=relaition_matrix(x2_latent)
        x3_relation_walk=relaition_matrix(x3_latent)
        x_fusion_relation_walk=relaition_matrix(x_fusion)
        
        #################################################
        MMfeature = torch.cat([x1_latent,x2_latent,x3_latent], dim=0)
        num_=x1_latent.size(0)
        views_relation=torch.zeros((view_num*num_,view_num*num_)).cuda()
        INN=torch.zeros((view_num*num_,view_num*num_)).cuda()
        I=torch.eye(num_)
        for view in range(1,view_num+1):
            views_relation[(view-1)*num_:view*num_,(view-1)*num_:view*num_]=locals()['x{0}_relation'.format(view)]
            #INN[(view-1)*num_:view*num_,(view-1)*num_:view*num_]=I
        for ii in range(1,view_num):
            for jj in range(ii+1,view_num+1):
                 view_inter=((locals()['x{0}_relation'.format(ii)]>=torch.mean(locals()['x{0}_relation'.format(ii)])).float())*((locals()['x{0}_relation'.format(jj)]>=torch.mean(locals()['x{0}_relation'.format(jj)])).float())
                 views_relation[(ii-1)*num_:ii*num_,(jj-1)*num_:jj*num_]=locals()['x{0}_relation'.format(jj)]*view_inter
                 views_relation[(jj-1)*num_:jj*num_,(ii-1)*num_:ii*num_]=locals()['x{0}_relation'.format(ii)]*view_inter
             
        views_relation=relaition_matrix2(views_relation)
        return [x1_train, x2_train, x3_train],[x1_hat,x2_hat,x3_hat],MMfeature,views_relation,[[x1_relation,x2_relation,x3_relation],[x1_relation_walk,x2_relation_walk,x3_relation_walk]],[x_fusion_relation,x_fusion_relation_walk]
              

               
class IMDD_FourView(nn.Module):
    # Dual contrastive prediction
    def __init__(self, config):
        """Constructor.

        Args:
            config: parameters defined in configure.py.
        """
        super(IMDD_FourView, self).__init__()
        self._config = config

        if self._config['Autoencoder']['arch1'][-1] != self._config['Autoencoder']['arch2'][-1]:
            raise ValueError('Inconsistent latent dim!')

        self._latent_dim = config['Autoencoder']['arch1'][-1]
        
        # View-specific autoencoders
        self.autoencoder1 = Autoencoder(config['Autoencoder']['arch1'], config['Autoencoder']['activations'],
                                        config['Autoencoder']['batchnorm'])
        self.autoencoder2 = Autoencoder(config['Autoencoder']['arch2'], config['Autoencoder']['activations'],
                                        config['Autoencoder']['batchnorm'])

        self.autoencoder3 = Autoencoder(config['Autoencoder']['arch3'], config['Autoencoder']['activations'],
                                        config['Autoencoder']['batchnorm'])
        self.autoencoder4 = Autoencoder(config['Autoencoder']['arch4'], config['Autoencoder']['activations'],
                                        config['Autoencoder']['batchnorm'])
        
    def forward(self,x1_train, x2_train,x3_train,x4_train, device):
        view_num=4
        x1_hat,x1_latent=self.autoencoder1(x1_train)
        x2_hat,x2_latent=self.autoencoder2(x2_train)
        x3_hat,x3_latent=self.autoencoder3(x3_train)
        x4_hat,x4_latent=self.autoencoder4(x4_train)
        x1_relation=relaition_matrix1(x1_latent)
        x2_relation=relaition_matrix1(x2_latent)
        x3_relation=relaition_matrix1(x3_latent)
        x4_relation=relaition_matrix1(x4_latent)
        x_fusion=torch.cat((x1_latent,x2_latent,x3_latent,x4_latent),1)
        x_fusion_relation=relaition_matrix1(x_fusion)
        
        x1_relation_walk=relaition_matrix(x1_latent)
        x2_relation_walk=relaition_matrix(x2_latent)
        x3_relation_walk=relaition_matrix(x3_latent)
        x4_relation_walk=relaition_matrix(x4_latent)
        x_fusion_relation_walk=relaition_matrix(x_fusion)
        #################################################
        MMfeature = torch.cat([x1_latent,x2_latent,x3_latent,x4_latent], dim=0)
        num_=x1_latent.size(0)
        views_relation=torch.zeros((view_num*num_,view_num*num_)).cuda()
        for view in range(1,view_num+1):
            views_relation[(view-1)*num_:view*num_,(view-1)*num_:view*num_]=locals()['x{0}_relation'.format(view)]
        for ii in range(1,view_num):
            for jj in range(ii+1,view_num+1):
                 view_inter=((locals()['x{0}_relation'.format(ii)]>=torch.mean(locals()['x{0}_relation'.format(ii)])).float())*((locals()['x{0}_relation'.format(jj)]>=torch.mean(locals()['x{0}_relation'.format(jj)])).float())
                 views_relation[(ii-1)*num_:ii*num_,(jj-1)*num_:jj*num_]=locals()['x{0}_relation'.format(jj)]*view_inter
                 views_relation[(jj-1)*num_:jj*num_,(ii-1)*num_:ii*num_]=locals()['x{0}_relation'.format(ii)]*view_inter
        #views_relation=relaition_matrix2(views_relation)
        return [x1_train, x2_train, x3_train, x4_train],[x1_hat,x2_hat,x3_hat, x4_hat],MMfeature,views_relation,[[x1_relation,x2_relation,x3_relation,x4_relation],[x1_relation_walk,x2_relation_walk,x3_relation_walk,x4_relation_walk]],[x_fusion_relation,x_fusion_relation_walk]
              
class IMDD_FiveView(nn.Module):
    # Dual contrastive prediction
    def __init__(self, config):
        """Constructor.

        Args:
            config: parameters defined in configure.py.
        """
        super(IMDD_FiveView, self).__init__()
        self._config = config

        if self._config['Autoencoder']['arch1'][-1] != self._config['Autoencoder']['arch2'][-1]:
            raise ValueError('Inconsistent latent dim!')

        self._latent_dim = config['Autoencoder']['arch1'][-1]
        
        # View-specific autoencoders
        self.autoencoder1 = Autoencoder(config['Autoencoder']['arch1'], config['Autoencoder']['activations'],
                                        config['Autoencoder']['batchnorm'])
        self.autoencoder2 = Autoencoder(config['Autoencoder']['arch2'], config['Autoencoder']['activations'],
                                        config['Autoencoder']['batchnorm'])
        self.autoencoder3 = Autoencoder(config['Autoencoder']['arch3'], config['Autoencoder']['activations'],
                                        config['Autoencoder']['batchnorm'])
        self.autoencoder4 = Autoencoder(config['Autoencoder']['arch4'], config['Autoencoder']['activations'],
                                        config['Autoencoder']['batchnorm'])
        self.autoencoder5 = Autoencoder(config['Autoencoder']['arch5'], config['Autoencoder']['activations'],
                                        config['Autoencoder']['batchnorm'])
    def forward(self,x1_train, x2_train,x3_train,x4_train,x5_train, device):
        view_num=5
        x1_hat,x1_latent=self.autoencoder1(x1_train)
        x2_hat,x2_latent=self.autoencoder2(x2_train)
        x3_hat,x3_latent=self.autoencoder3(x3_train)
        x4_hat,x4_latent=self.autoencoder4(x4_train)
        x5_hat,x5_latent=self.autoencoder5(x5_train)
        x1_relation=relaition_matrix1(x1_latent,similarity="cosine")
        x2_relation=relaition_matrix1(x2_latent,similarity="cosine")
        x3_relation=relaition_matrix1(x3_latent,similarity="cosine")
        x4_relation=relaition_matrix1(x4_latent,similarity="cosine")
        x5_relation=relaition_matrix1(x5_latent,similarity="cosine")
        
        x_fusion=torch.cat((x1_latent,x2_latent,x3_latent,x4_latent,x5_latent),1)
        x_fusion_relation=relaition_matrix1(x_fusion,similarity="cosine")
        x1_relation_walk=relaition_matrix(x1_latent,similarity="cosine")
        x2_relation_walk=relaition_matrix(x2_latent,similarity="cosine")
        x3_relation_walk=relaition_matrix(x3_latent,similarity="cosine")
        x4_relation_walk=relaition_matrix(x4_latent,similarity="cosine")
        x5_relation_walk=relaition_matrix(x5_latent,similarity="cosine")
        x_fusion_relation_walk=relaition_matrix(x_fusion,similarity="cosine")
        #################################################
        MMfeature = torch.cat([x1_latent,x2_latent,x3_latent,x4_latent,x5_latent], dim=0)
        num_=x1_latent.size(0)
        views_relation=torch.zeros((view_num*num_,view_num*num_)).cuda()
        for view in range(1,view_num+1):
            views_relation[(view-1)*num_:view*num_,(view-1)*num_:view*num_]=locals()['x{0}_relation'.format(view)]
        for ii in range(1,view_num):
            for jj in range(ii+1,view_num+1):
                 view_inter=((locals()['x{0}_relation'.format(ii)]>=0.5).float())*((locals()['x{0}_relation'.format(jj)]>=0.5).float())
                 views_relation[(ii-1)*num_:ii*num_,(jj-1)*num_:jj*num_]=locals()['x{0}_relation'.format(jj)]*view_inter
                 views_relation[(jj-1)*num_:jj*num_,(ii-1)*num_:ii*num_]=locals()['x{0}_relation'.format(ii)]*view_inter
        views_relation=relaition_matrix2(views_relation)
        return [x1_train, x2_train, x3_train, x4_train,x5_train ],[x1_hat,x2_hat,x3_hat, x4_hat, x5_hat],MMfeature,views_relation,[[x1_relation,x2_relation,x3_relation,x4_relation,x5_relation],[x1_relation_walk,x2_relation_walk,x3_relation_walk,x4_relation_walk,x5_relation_walk]],[x_fusion_relation,x_fusion_relation_walk]
              




class IMDD_SixView(nn.Module):
    # Dual contrastive prediction
    def __init__(self, config):
        """Constructor.

        Args:
            config: parameters defined in configure.py.
        """
        super(IMDD_SixView, self).__init__()
        self._config = config

        if self._config['Autoencoder']['arch1'][-1] != self._config['Autoencoder']['arch2'][-1]:
            raise ValueError('Inconsistent latent dim!')

        self._latent_dim = config['Autoencoder']['arch1'][-1]
        
        # View-specific autoencoders
        self.autoencoder1 = Autoencoder(config['Autoencoder']['arch1'], config['Autoencoder']['activations'],
                                        config['Autoencoder']['batchnorm'])
        self.autoencoder2 = Autoencoder(config['Autoencoder']['arch2'], config['Autoencoder']['activations'],
                                        config['Autoencoder']['batchnorm'])
        self.autoencoder3 = Autoencoder(config['Autoencoder']['arch3'], config['Autoencoder']['activations'],
                                        config['Autoencoder']['batchnorm'])
        self.autoencoder4 = Autoencoder(config['Autoencoder']['arch4'], config['Autoencoder']['activations'],
                                        config['Autoencoder']['batchnorm'])
        self.autoencoder5 = Autoencoder(config['Autoencoder']['arch5'], config['Autoencoder']['activations'],
                                        config['Autoencoder']['batchnorm'])
        self.autoencoder6 = Autoencoder(config['Autoencoder']['arch6'], config['Autoencoder']['activations'],
                                        config['Autoencoder']['batchnorm'])
    def forward(self,x1_train, x2_train,x3_train,x4_train,x5_train,x6_train, device):
        view_num=6
        x1_hat,x1_latent=self.autoencoder1(x1_train)
        x2_hat,x2_latent=self.autoencoder2(x2_train)
        x3_hat,x3_latent=self.autoencoder3(x3_train)
        x4_hat,x4_latent=self.autoencoder4(x4_train)
        x5_hat,x5_latent=self.autoencoder5(x5_train)
        x6_hat,x6_latent=self.autoencoder6(x6_train)
        x1_relation=relaition_matrix1(x1_latent,similarity="cosine")
        x2_relation=relaition_matrix1(x2_latent,similarity="cosine")
        x3_relation=relaition_matrix1(x3_latent,similarity="cosine")
        x4_relation=relaition_matrix1(x4_latent,similarity="cosine")
        x5_relation=relaition_matrix1(x5_latent,similarity="cosine")
        x6_relation=relaition_matrix1(x6_latent,similarity="cosine")
        ################################################
        
        
        x_fusion=torch.cat((x1_latent,x2_latent,x3_latent,x4_latent,x5_latent,x6_latent),1)
        x_fusion_relation=relaition_matrix1(x_fusion,similarity="cosine")
        
        x1_relation_walk=relaition_matrix(x1_latent,similarity="cosine")
        x2_relation_walk=relaition_matrix(x2_latent,similarity="cosine")
        x3_relation_walk=relaition_matrix(x3_latent,similarity="cosine")
        x4_relation_walk=relaition_matrix(x4_latent,similarity="cosine")
        x5_relation_walk=relaition_matrix(x5_latent,similarity="cosine")
        x6_relation_walk=relaition_matrix(x6_latent,similarity="cosine")
        x_fusion_relation_walk=relaition_matrix(x_fusion,similarity="cosine")
        
        #################################################
        MMfeature = torch.cat([x1_latent,x2_latent,x3_latent,x4_latent,x5_latent,x6_latent], dim=0)
        num_=x1_latent.size(0)
        views_relation=torch.zeros((view_num*num_,view_num*num_)).cuda()
       
        for view in range(1,view_num+1):
            views_relation[(view-1)*num_:view*num_,(view-1)*num_:view*num_]=locals()['x{0}_relation'.format(view)]
         
        for ii in range(1,view_num):
            for jj in range(ii+1,view_num+1):
                 view_inter=((locals()['x{0}_relation'.format(ii)]>=torch.mean(locals()['x{0}_relation'.format(ii)])).float())*((locals()['x{0}_relation'.format(jj)]>=torch.mean(locals()['x{0}_relation'.format(jj)])).float())
                 views_relation[(ii-1)*num_:ii*num_,(jj-1)*num_:jj*num_]=locals()['x{0}_relation'.format(jj)]*view_inter
                 views_relation[(jj-1)*num_:jj*num_,(ii-1)*num_:ii*num_]=locals()['x{0}_relation'.format(ii)]*view_inter
        views_relation=relaition_matrix2(views_relation)
        return [x1_train, x2_train, x3_train, x4_train,x5_train,x6_train],[x1_hat,x2_hat,x3_hat, x4_hat, x5_hat,x6_hat],MMfeature,views_relation,[[x1_relation,x2_relation,x3_relation,x4_relation,x5_relation,x6_relation],[x1_relation_walk,x2_relation_walk,x3_relation_walk,x4_relation_walk,x5_relation_walk,x6_relation_walk]],[x_fusion_relation,x_fusion_relation_walk]