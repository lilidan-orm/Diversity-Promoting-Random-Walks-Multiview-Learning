def get_default_config(data_name):
    if data_name in ['scene']:#sigmoid
        return dict(
            view=2,
            label_num=6,
            training=dict(
                lr=3.0e-4,
                start_completion=20,
                batch_size=64,
                epoch=50,
            ),
            Autoencoder=dict(
                arch1=[98, 100,  50],
                arch2=[196,  100, 50],
                activations='tanh',
                batchnorm=True,
            )
           
        )

    elif data_name in ['pascal']:
        """The default configs."""
        return dict(
            view=4,
            label_num=20,
            training=dict(
                lr=1.0e-4,
                start_completion=50,
                batch_size=64,
                epoch=50,
            ),
            Autoencoder=dict(
                arch1=[100, 1024,  100],
                arch2=[512, 1024, 100],
                arch3=[1000, 1024, 100],
                arch4=[4096, 1024, 100],
                activations='tanh',
                batchnorm=True,
            )
            

        )
    elif data_name in ['corel5k']:#Sigmoid
        """The default configs."""
        return dict(
            view=4,
            label_num=260,
            Autoencoder=dict(
                arch1=[100, 1024,100],
                arch2=[512, 1024,  100],
                arch3=[1000, 1024, 100],
                arch4=[4096, 1024, 100],
                activations='tanh',
                batchnorm=True,
            ),

            training=dict(
                lr=1.0e-4,
                start_completion=50,
                batch_size=64,
                epoch=50,
            ),
        )
    
    
    else:
        raise Exception('Undefined data name')
