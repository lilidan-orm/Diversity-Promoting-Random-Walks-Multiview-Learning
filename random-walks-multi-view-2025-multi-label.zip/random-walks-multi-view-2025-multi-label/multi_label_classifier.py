import torch
import torch.nn as nn
import torch.nn.functional as F
#from torch.nn.modules.module import Module
from torch.nn.parameter import Parameter
import torch.utils.data as data
from torch.utils.data import DataLoader
use_cuda = torch.cuda.is_available()
class ViewsDataset(data.Dataset):
    def __init__(self, views_features, labels):
        self.views_features = views_features
        self.labels = labels
       
    def __len__(self):
        return self.labels.shape[0]

    def __getitem__(self, item):
      
        feature = self.views_features[item]
        return feature, self.labels[item]

class multi_label_net(nn.Module):
        def __init__(self, in_dim, n_hidden_1,out_dim,label_num):
           super(multi_label_net, self).__init__()
           self.layer1 = nn.Sequential(nn.Linear(in_dim, n_hidden_1),nn.BatchNorm1d(n_hidden_1), nn.ReLU(True))
           self.layer2 = nn.Sequential(nn.Linear(n_hidden_1, out_dim),nn.BatchNorm1d(out_dim), nn.ReLU(True))
           self.dropout=nn.Dropout(0.5)
           self.layer3=nn.Sequential(nn.Linear(out_dim, label_num))
        def forward(self, x):
           x = self.layer1(x)
           x=self.dropout(x)
           feat = self.layer2(x)
           feat=self.dropout(feat)
           out=self.layer3(feat)
           return out

def My_logit_ML_loss(view_predictions, true_labels):
    view_predictions_sig = torch.sigmoid(view_predictions)
    criterion = nn.BCELoss()
    ML_loss = criterion(view_predictions_sig, true_labels)
    return ML_loss


def multi_label_model(X_train,X_test, gt_train, gt_test, lr, epochs, batch_size,in_dim,label_num):
    
    views_dataset_train = ViewsDataset(X_train, gt_train)
    views_train_loader = DataLoader(views_dataset_train, batch_size=batch_size, shuffle=True,
                                   num_workers=0)
    views_dataset_test = ViewsDataset(X_test, gt_test)
    views_test_loader = DataLoader(views_dataset_test, batch_size=batch_size, shuffle=False,
                                   num_workers=0)
    
    net =multi_label_net(in_dim,512,512,label_num);
    
    ###################################
    optimizer = torch.optim.Adam(net.parameters(), lr=lr)
    #scheduler=torch.optim.lr_scheduler.StepLR(optimizer,step_size=30,gamma=0.9)

    for epoch in range(epochs):
       num_batches = len(views_train_loader)
       running_loss, proc_size = 0, 0
       net.train()
    
       for batch_idx,train_data in enumerate(views_train_loader):
         inputs_x,label_t= train_data
            
         optimizer.zero_grad()
         if use_cuda:
            inputs_x,label_t = inputs_x.cuda(),label_t.cuda(non_blocking=True)
            net = net.cuda()
         output= net(inputs_x)
         loss = My_logit_ML_loss(output, label_t.float())
         loss.backward()
         optimizer.step()
         #scheduler.step()
         running_loss += loss.item()
         proc_size += batch_size
         if batch_idx % 100 == 0:    # print every 2000 mini-batches
            avg_loss =running_loss / 100
            #print('Multi_Label_Epoch {:2d} | Batch {:3d}/{:3d} |  Train Loss {:5.4f}'.
                     # format(epoch,batch_idx, num_batches, avg_loss))
            running_loss, proc_size = 0, 0
    
    #print('-' * 10,'Test Start','-' * 10)
    labels_prediction = []
    label = []
    net.eval()
    with torch.no_grad():
        for data in views_test_loader:
            input_test, labels_t = data
            label_pre_t= net(input_test.cuda())
            label_view_test = torch.sigmoid(label_pre_t);
            labels_prediction.append(label_view_test)
            label.append(labels_t)
    labels_prediction_test = torch.cat(labels_prediction).cpu().numpy()
    target = torch.cat(label).cpu().numpy()
    return labels_prediction_test, target

