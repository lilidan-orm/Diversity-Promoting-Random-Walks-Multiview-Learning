
import random
import sys
import scipy.io as sio
import numpy as np
import torch
import os
import torch.utils.data as data
from sklearn import preprocessing
import h5py
from sklearn.model_selection import KFold
from util import  data_clean
# 


class FourView_Datasets(data.Dataset):
    def __init__(self,config, train=True,fold=0):
        self._config=config
        self.train = train
        self.fold=fold
        data_name = self._config['dataset']
        main_dir = r'D:\paper_code\random-walks-multi-view-2025-multi-label\dataset'
        
        if data_name=="corel5k":
            data_multiview = sio.loadmat(os.path.join(main_dir,"corel5k", data_name + '.mat'))
            data_view1_train=data_multiview['corel5k_train_DenseHue']
            data_view2_train=data_multiview['corel5k_train_Gist']
            data_view3_train=data_multiview['corel5k_train_DenseSift']
            data_view4_train=data_multiview['corel5k_train_Hsv']
            #############################
            data_view1_test=data_multiview['corel5k_test_DenseHue']
            data_view2_test=data_multiview['corel5k_test_Gist']
            data_view3_test=data_multiview['corel5k_test_DenseSift']
            data_view4_test=data_multiview['corel5k_test_Hsv']
        elif data_name=="pascal":
            data_multiview = sio.loadmat(os.path.join(main_dir,"pascal", data_name + '.mat'))
            data_view1_train=data_multiview['pascal07_train_DenseHue']
            data_view2_train=data_multiview['pascal07_train_Gist']
            data_view3_train=data_multiview['pascal07_train_DenseSift']
            data_view4_train=data_multiview['pascal07_train_Hsv']
            #############################
            data_view1_test=data_multiview['pascal07_test_DenseHue']
            data_view2_test=data_multiview['pascal07_test_Gist']
            data_view3_test=data_multiview['pascal07_test_DenseSift']
            data_view4_test=data_multiview['pascal07_test_Hsv']
        elif data_name=="espgame":
            data_multiview = sio.loadmat(os.path.join(main_dir,"espgame", data_name + '.mat'))
            data_view1_train=data_multiview['espgame_train_DenseHue']
            data_view2_train=data_multiview['espgame_train_Gist']
            data_view3_train=data_multiview['espgame_train_DenseSift']
            data_view4_train=data_multiview['espgame_train_Hsv']
            #############################
            data_view1_test=data_multiview['espgame_test_DenseHue']
            data_view2_test=data_multiview['espgame_test_Gist']
            data_view3_test=data_multiview['espgame_test_DenseSift']
            data_view4_test=data_multiview['espgame_test_Hsv']
            
        
        label_train_char = sio.loadmat(os.path.join(main_dir,data_name, 'label_train.mat'))
        label_train=label_train_char['label_train']
        label_test_char = sio.loadmat(os.path.join(main_dir,data_name, 'label_test.mat'))
        label_test=label_test_char['label_test']
        ####################################################
        data_view1=np.vstack((data_view1_train,data_view1_test))
        data_view2=np.vstack((data_view2_train,data_view2_test))
        data_view3=np.vstack((data_view3_train,data_view3_test))
        data_view4=np.vstack((data_view4_train,data_view4_test))
        labels=np.vstack((label_train,label_test))
    
        
        view=[]
        for ii in range(1,5):
            view.append(torch.from_numpy(locals()['data_view{0}'.format(ii)].astype(np.float64)))
        view,labels=data_clean(view,labels)
        
        kf = KFold(n_splits=5,shuffle=True, random_state=0)
        index_=[]
        for index in kf.split(data_view1):
            index_.append(index)
        train_index=index_[self.fold][0]
        test_index=index_[self.fold][1]
        data_view1_train, data_view1_test=data_view1[train_index],data_view1[test_index]
        data_view2_train, data_view2_test=data_view2[train_index],data_view2[test_index]
        data_view3_train, data_view3_test=data_view3[train_index],data_view3[test_index]
        data_view4_train, data_view4_test=data_view4[train_index],data_view4[test_index]
        label_train,label_test=labels[train_index],labels[test_index]
        #####################################################
        min_max_scaler_1 = preprocessing.MaxAbsScaler().fit(data_view1_train)
        view1_train=min_max_scaler_1.transform(data_view1_train)
        view1_test=min_max_scaler_1.transform(data_view1_test)
        min_max_scaler_2 = preprocessing.MaxAbsScaler().fit(data_view2_train)
        view2_train=min_max_scaler_2.transform(data_view2_train)
        view2_test=min_max_scaler_2.transform(data_view2_test)
        min_max_scaler_3 =preprocessing.MaxAbsScaler().fit(data_view3_train)
        view3_train=min_max_scaler_3.transform(data_view3_train)
        view3_test=min_max_scaler_3.transform(data_view3_test)
        min_max_scaler_4 = preprocessing.MaxAbsScaler().fit(data_view4_train)
        view4_train=min_max_scaler_4.transform(data_view4_train)
        view4_test=min_max_scaler_4.transform(data_view4_test)


        if self.train:
            self.train_data_view1 = view1_train
            self.train_data_view2 = view2_train
            self.train_data_view3 = view3_train
            self.train_data_view4 = view4_train
            self.train_labels = label_train
                
        else:
            self.test_data_view1= view1_test
            self.test_data_view2= view2_test
            self.test_data_view3=view3_test
            self.test_data_view4=view4_test
            self.test_labels = label_test
                      
    def __getitem__(self, index):
        if self.train:
            view1= self.train_data_view1[index]
            view2=self.train_data_view2[index]
            view3= self.train_data_view3[index]
            view4=self.train_data_view4[index]
            target = self.train_labels[index]
                    
        else:
            view1= self.test_data_view1[index]
            view2=self.test_data_view2[index]
            view3= self.test_data_view3[index]
            view4=self.test_data_view4[index]
            target = self.test_labels[index]
           
       
        view1 = torch.from_numpy(view1).float()
        view2 = torch.from_numpy(view2).float()
        view3 = torch.from_numpy(view3).float()
        view4 = torch.from_numpy(view4).float()
        
        
        
        target = target.astype(np.int64)
        return view1, view2,view3,view4,target
    
    def __len__(self):
        if self.train:
            return len(self.train_labels)
        else:
            return len(self.test_labels)
        

class TwoView_Datasets(data.Dataset):
    def __init__(self,config, train=True,fold=0):
        self._config=config
        self.train = train
        self.fold=fold
        data_name = self._config['dataset']
        main_dir = r'D:\paper_code\random-walks-multi-view-2025-multi-label\dataset'
        data_multiview = sio.loadmat(os.path.join(main_dir,data_name + '.mat'))
        if data_name=="scene":
             data_view1=data_multiview['X1']
             data_view2=data_multiview['X2']
             label=data_multiview['Y']
        elif data_name=="Yeast":
             data_view1=data_multiview['data'][0,0]
             data_view2=data_multiview['data'][1,0]
             label=data_multiview['target']
        
        view=[]
        for ii in range(1,3):
            view.append(torch.from_numpy(locals()['data_view{0}'.format(ii)].astype(np.float64)))
        view,label=data_clean(view,label)

        kf = KFold(n_splits=5,shuffle=True, random_state=0)
        index_=[]
        for index in kf.split(view[0]):
            index_.append(index)
        train_index=index_[self.fold][0]
        test_index=index_[self.fold][1]
        data_view1_train, data_view1_test=view[0][train_index],view[0][test_index]
        data_view2_train, data_view2_test=view[1][train_index],view[1][test_index]
        label_train,label_test=label[train_index],label[test_index]
        min_max_scaler_1 = preprocessing.MaxAbsScaler().fit(data_view1_train)
        view1_train=min_max_scaler_1.transform(data_view1_train)
        view1_test=min_max_scaler_1.transform(data_view1_test)
        min_max_scaler_2 = preprocessing.MaxAbsScaler().fit(data_view2_train)
        view2_train=min_max_scaler_2.transform(data_view2_train)
        view2_test=min_max_scaler_2.transform(data_view2_test)
        
       
       
       
        if self.train:
            self.train_data_view1 = view1_train
            self.train_data_view2 =  view2_train
            self.train_labels = label_train
                
        else:
            self.test_data_view1= view1_test
            self.test_data_view2= view2_test
            self.test_labels = label_test
                      
    def __getitem__(self, index):
        if self.train:
            view1= self.train_data_view1[index]
            view2=self.train_data_view2[index]
            target = self.train_labels[index]
           
           
        else:
            view1= self.test_data_view1[index]
            view2=self.test_data_view2[index]
            target = self.test_labels[index]
           
       
        view1 = torch.from_numpy(view1).float()
        view2 = torch.from_numpy(view2).float()
        
        
        
        target = target.astype(np.int64)
        return view1, view2,target
    
    def __len__(self):
        if self.train:
            return len(self.train_labels)
        else:
            return len(self.test_labels)
