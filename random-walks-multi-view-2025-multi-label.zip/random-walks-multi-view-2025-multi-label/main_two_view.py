# -*- coding: utf-8 -*-
"""
Created on Tue Aug 24 16:16:34 2021

@author: danli
"""
import torch
from torch.autograd import Variable
import sys
import time
import itertools
import numpy as np
from multi_view_data import *
from configure_clustering_multiview import get_default_config
from sklearn.cluster import KMeans
from metrics import  get_avg_HammingLoss,get_avg_AveragePrecision,get_avg_OneError,get_avg_RankingLoss,get_avg_Coverage,get_avg_MacroF1,get_avg_MicroF1
from torch.utils.data import DataLoader
from multi_label_classifier import multi_label_model
import scipy.io as sio
import os
os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
os.environ["CUDA_VISIBLE_DEVICES"] = '0'
use_cuda = torch.cuda.is_available()
device = torch.device('cuda:0' if use_cuda else 'cpu')

import warnings
warnings.filterwarnings("ignore")
from multi_view_loss import MultiView_all_loss
from model import IMDD_TwoView



#########################################################################

def train():
    net = IMDD_TwoView(config)
    lossfunc1 = MultiView_all_loss(batch_size)
    optimizer = torch.optim.Adam(itertools.chain(net.autoencoder1.parameters(),net.autoencoder2.parameters()
                                                ),lr=config['training']['lr']) 
    
    print('-' * 10,'Training Start','-' * 10)
    epochs=config['training']['epoch']
    for epoch in range(epochs):
        net.train()
        num_batches = len(trainloader)
        loss_all,loss_AE,loss_contrast= 0,0,0
        for batch_idx,train_data in enumerate(trainloader):
            inputs_x1, inputs_x2,label_train= train_data 
            inputs_x1,inputs_x2,label_train= inputs_x1.to(device),inputs_x2.to(device),label_train.to(device)
            
            net=net.to(device)
            list_x,list_hat,MMfeature,views_relation,list_relation, list_fusion_relation=net(inputs_x1,inputs_x2,device)
            loss,loss_pre_AE, loss_pre_contrast= lossfunc1(list_x,list_hat,MMfeature,views_relation,list_relation, list_fusion_relation,2,epoch)
            
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            # for name,param in net.named_parameters():
            #     if param.requires_grad:
            #         print(name,'requires')

            #     else:
            #         print(name,'does not')
            loss_all += loss.item()
            loss_AE  += loss_pre_AE.item()
            loss_contrast += loss_pre_contrast.item()
          
        output = "Epoch : {:.0f}/{:.0f} ===> Loss_all = {:.4f}===> Loss_AE = {:.4f} " \
                     "===> loss_relation_graph = {:.4f}" \
                .format((epoch + 1), epochs, loss_all, loss_AE, loss_contrast)
        print(output)
       
        
    print('-' * 10,'Test Start','-' * 10)
    x1_feature = []
    x2_feature = []
    label_all_test=[]
    x1_feature_train = []
    x2_feature_train = []
    label_all_train=[]
    net.eval()
    with torch.no_grad():
        for data in testloader:
            x_view=[]
            x1,x2,labels= data
            list_x,list_hat,MMfeature,views_relation,list_relation, list_fusion_relation= net(x1.to(device),x2.to(device),device)
            final_view_features=torch.mm(views_relation,MMfeature)
            
            for view in range(2):
                x_view.append(final_view_features[view*x1.size(0):(view+1)*x1.size(0),:])
            
            x1_feature.append(x_view[0])
            x2_feature.append(x_view[1])     
            label_all_test.append(labels)
        x_all_view_test =(torch.cat(x1_feature).cpu().numpy()+torch.cat(x2_feature).cpu().numpy())/2
        label_all_test = torch.cat(label_all_test).cpu().numpy()
        label_all_test=label_all_test.reshape(len(label_all_test),config['label_num'])
        #############################################
        for data in trainloader:
            x_view=[]
            x1,x2,labels= data
            _,_,MMfeature,views_relation,_, _= net(x1.to(device),x2.to(device),device)
            final_view_features=torch.mm(views_relation,MMfeature)
            
            for view in range(2):
                x_view.append(final_view_features[view*x1.size(0):(view+1)*x1.size(0),:])
            
            x1_feature_train.append(x_view[0])
            x2_feature_train.append(x_view[1])     
            label_all_train.append(labels)
        x_all_view_train =(torch.cat(x1_feature_train).cpu().numpy()+torch.cat(x2_feature_train).cpu().numpy())/2
        label_all_train = torch.cat(label_all_train).cpu().numpy()
        label_all_train=label_all_train.reshape(len(label_all_train),config['label_num'])
    ##########################################
    label_pred,label_all=multi_label_model(x_all_view_train,x_all_view_test,label_all_train,label_all_test,0.001, 50, 100,x_all_view_test.shape[1],label_all_test.shape[1])
    return label_pred,label_all


dataset = {
    0: "scene",
    
}
dataset = dataset[0]
config = get_default_config(dataset)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           
config['dataset'] = dataset



times=5 
pred_all=[]
outputs=[]
true_labels=[]
for t in range(times):
    print('-' * 10,t+1,'-' * 10)
    train_dataset=TwoView_Datasets(config,train=True,fold=t)
    test_dataset=TwoView_Datasets(config,train=False,fold=t)
    batch_size=config['training']['batch_size']
    trainloader = DataLoader(train_dataset, batch_size,
                                         shuffle=True, num_workers=0)
    testloader=DataLoader(test_dataset, batch_size,
                                         shuffle=False, num_workers=0)
    print('Finish loading the data....')
    label_prediction,label_all=train()
    pred_all.append(label_prediction)
    true_labels.append(np.array(label_all))
    output = np.array(label_prediction > 0.5)
    outputs.append(output)

hl_avg,hl_std=get_avg_HammingLoss(outputs, true_labels,times)
ap_avg,ap_std=get_avg_AveragePrecision(pred_all,true_labels,times)
oe_avg,oe_std=get_avg_OneError(pred_all,true_labels,times)
rl_avg,rl_std=get_avg_RankingLoss(pred_all,true_labels,times)
cov_avg,cov_std=get_avg_Coverage(pred_all,true_labels,times)
maf1_avg,maf1_std=get_avg_MacroF1(outputs,true_labels,times)
mif1_avg,mif1_std=get_avg_MicroF1(outputs,true_labels,times)

print('HammingLoss: {HammingLoss:.4f}\t'
                'AP: {AP:.4f}\t'
                'OneError:{OneError:.4f}\t'
                'RankingLoss:{RankingLoss:.4f}\t'
                'Coverage:{Coverage:.4f}\t'
                'MacroF1:{MacroF1:.4f}\t'
                'MicroF1:{MicroF1:.4f}'.format(HammingLoss=hl_avg,AP=ap_avg,OneError=oe_avg,RankingLoss=rl_avg,Coverage=cov_avg,MacroF1=maf1_avg,MicroF1=mif1_avg))
print('HammingLoss: {HammingLoss:.4f}\t'
                'AP: {AP:.4f}\t'
                'OneError:{OneError:.4f}\t'
                'RankingLoss:{RankingLoss:.4f}\t'
                'Coverage:{Coverage:.4f}\t'
                'MacroF1:{MacroF1:.4f}\t'
                'MicroF1:{MicroF1:.4f}'.format(HammingLoss=hl_std,AP=ap_std,OneError=oe_std,RankingLoss=rl_std,Coverage=cov_std,MacroF1=maf1_std,MicroF1=mif1_std))
