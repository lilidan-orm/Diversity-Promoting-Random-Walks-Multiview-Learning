import torch
import torch.nn as nn
from torch.distributions.multivariate_normal import MultivariateNormal
L2norm = nn.functional.normalize
# def relaition_matrix (x):
#     sigma=1
#     x_distance = -(torch.norm(x[:, None]-x, dim=2, p=2)*torch.norm(x[:, None]-x, dim=2, p=2))
#     b = 2 *sigma**2
#     W = torch.exp(x_distance/b)
#     #W=W*(W>=0.5).float()
#     return W
def relaition_matrix_ (x):
  N=x.size(0)
  tmp = torch.norm(x, 2, 1)+1e-6;
  x_norm = x / tmp.view(N, -1);
  x_relation=torch.mm( x_norm,x_norm.t())  
  #x_relation=x_relation*(x_relation>=0).float()
  x_relation=torch.clamp(x_relation,min=0.0)
  return x_relation

def data_clean(view, target):
    eps = 1e-5
    for i in range(len(view)):
        valid_col = []
        print('less:', (view[i] < 0).sum())
        #ict = torch.zeros(view[i].shape[1], target.shape[1])
        #for j in range(view[i].shape[0]):
            #for k in range(view[i].shape[1]):
                #dict[k][target[]]
        for j in range(view[i].shape[1]):
            if not (view[i][:, j] == 0).sum() == view[i][:, j].shape[0]:
                valid_col.append(j)
            # print('shape:{} {} {}'.format(view[i].shape, view[i][:,j].shape, view[i][0].shape))
            # print(view[i][:,j])
            view[i][:,j] = (view[i][:,j] - view[i][:,j].mean() + eps) / (torch.std((view[i][:,j])) + eps)
            view[i][:,j] -= view[i][:,j].min()
            #view[i][:,j] = view[i][:,j] / (view[i][:,j].max() + eps) + eps
            # print('aft:')
            # print(view[i][:,j])
            if i == 70:
                print('j:{} view:{} shape:{}'.format(j, view[i][:, j], view[i][:, j].shape))
        view[i] = view[i][:, valid_col]
        print('i:{} viewi:{}'.format(i, view[i].shape))
    # return view, target
    # print(view[5][3195])
    # x = input()
    for i in range(len(view)):
        cnt = 0
        cnt_dim = 0
        print(view[i][0,:30])
        print('i:{} pos:{} num:{} per:{}'.format(i, (view[i] == 0).sum(), view[i].shape[0] * view[i].shape[1],
                                                 (view[i] == 0).sum() / (view[i].shape[0] * view[i].shape[1])))
        for j in range(view[i].shape[0]):
            if (view[i][j] == 0).sum() == view[i][j].shape[0]:
                cnt += 1
        for j in range(view[i].shape[1]):
            if (view[i][:, j] == 0).sum() == view[i][:, j].shape[0]:
                cnt_dim += 1
                # print('i:{} j:{} sum:{} len:{}'.format(i, j, (view[i][j] == 0).sum(), view[i][j].shape[0]))
                # print(view[i][j])
        print('i:{} cnt:{} cnt_dim:{}'.format(i, cnt, cnt_dim))
        # for j in range(view[i].shape[1]):
        # cnt = 0
        # for k in range(view[i].shape[0]):
        # if view[i][k][j] == 0:
        # cnt += 1
        # print('i:{} j:{} sum:{} len:{}'.format(i, j, (view[i][:,j] == 0).sum(), view[i][:,j].shape[0]))
        # view[i][:,j] = (view[i][:,j] - view[i][:,j].mean()) / torch.std(torch.from_numpy(view[i][:,j]))
    return view, target
def relaition_matrix(z, temperature=0.1, step: int = 5, similarity="kernel"):#2
        if similarity=="kernel":
              z = L2norm(z)
              G = (2 - 2 * (z @ z.t())).clamp(min=0.)
              G = torch.exp(-G / temperature)
              G = G / G.sum(dim=1, keepdim=True)
        else:
              G=relaition_matrix_(z)
        G = torch.matrix_power(G, step)
        alpha = 0.5
        G = torch.eye(G.shape[0]).cuda() * alpha + G * (1 - alpha)
        return G

def relaition_matrix1(z, temperature=0.1, step: int = 1,similarity="kernel"):
        if similarity=="kernel":
              z = L2norm(z)
              G = (2 - 2 * (z @ z.t())).clamp(min=0.)
              G = torch.exp(-G / temperature)
              G = G / G.sum(dim=1, keepdim=True)
        else:
              G=relaition_matrix_(z)
        G = torch.matrix_power(G, step)
        alpha = 0.5
        G = torch.eye(G.shape[0]).cuda() * alpha + G * (1 - alpha)
        return G
def relaition_matrix2(G, step: int = 5):
        G = torch.matrix_power(G, step)
        alpha = 0.5
        G = torch.eye(G.shape[0]).cuda() * alpha + G * (1 - alpha)
        return G

